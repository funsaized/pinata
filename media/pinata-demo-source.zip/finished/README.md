# Pulse

A tiny service health checker. The starting version checks HTTP endpoints serially,
has no deadlines or retries, and prints only name + status. `npm run demo` runs
five real local HTTP endpoints: API/Web healthy, Payments returns 503 once,
Search is slow, Legacy returns 404.

## Target behavior

Implement `checkServices(services, options)` with configurable `concurrency` (default 3,
positive integer), `timeoutMs` (default 1000, positive finite number no greater than 2147483647), `retries`
(default 1, integer 0..3), and `fetchImpl` (default fetch). Preserve input order and
return `{name,url,status,code,latencyMs,attempts}` per service. Status is `up`, `down`,
or `timeout`. Every request attempt has its own AbortController deadline. Retry
network failures, timeouts, 429 and 5xx; do not retry other 4xx. `attempts` is the
number actually attempted, at most retries + 1. Consume/cancel response bodies to
avoid leaking sockets. Empty input returns []. Invalid options throw RangeError
even on empty input. Concurrency limits whole service checks including retries.

Implement `formatReport(results)` as a readable terminal table with SERVICE,
STATUS, HTTP, LATENCY, ATTEMPTS, and a summary of up/down/timeout counts. Unicode
and color are welcome, but keep it readable without ANSI. It returns a string,
does not print or mutate input, and handles empty input.

Use node:test, no dependencies, fake fetch implementations, and deterministic
tests. The checker and reporter can be built independently against this contract.

## Scope and verification

Service names are printable ASCII and URLs are valid HTTP URLs. ANSI/control-string sanitization is outside this feature. No terminal color escapes are needed. Keep report output readable for these normal inputs. Omitted/undefined options use defaults; explicitly invalid values (including null options or non-callable fetchImpl) throw RangeError.

The per-attempt deadline must also bound response-body cleanup: a never-settling cancel() must not strand a concurrency slot. Late or failed cleanup must not produce an unhandled rejection. Retry 500..599, 429, network failures and timeouts. Preserve all existing feature tests when repairing.

Write at least ten individually named checker tests covering ordering, maximum concurrency, retries, no retry on 404, network failure, deadlines, cleanup, metadata, empty input and invalid options. Write four reporter tests for columns/data, summary, empty input, and non-mutation. Use node --test --test-isolation=none for human-readable verification.
