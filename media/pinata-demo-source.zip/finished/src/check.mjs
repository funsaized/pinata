const MAX_TIMEOUT = 2_147_483_647;

function cancelBody(response) {
  try {
    const cancel = response?.body?.cancel;
    if (typeof cancel === 'function') Promise.resolve(cancel.call(response.body)).catch(() => {});
  } catch { /* late cleanup is best effort */ }
}

function optionsFor(options) {
  if (options === null || (typeof options !== 'object' && typeof options !== 'function')) throw new RangeError('options must be an object');
  const concurrency = options.concurrency === undefined ? 3 : options.concurrency;
  const timeoutMs = options.timeoutMs === undefined ? 1000 : options.timeoutMs;
  const retries = options.retries === undefined ? 1 : options.retries;
  const fetchImpl = options.fetchImpl === undefined ? fetch : options.fetchImpl;
  if (!Number.isInteger(concurrency) || concurrency <= 0) throw new RangeError('concurrency must be a positive integer');
  if (typeof timeoutMs !== 'number' || !Number.isFinite(timeoutMs) || timeoutMs <= 0 || timeoutMs > MAX_TIMEOUT) throw new RangeError('invalid timeoutMs');
  if (!Number.isInteger(retries) || retries < 0 || retries > 3) throw new RangeError('invalid retries');
  if (typeof fetchImpl !== 'function') throw new RangeError('fetchImpl must be callable');
  return { concurrency, timeoutMs, retries, fetchImpl };
}

export async function checkServices(services, options = {}) {
  const { concurrency, timeoutMs, retries, fetchImpl } = optionsFor(options);
  if (!Array.isArray(services)) throw new TypeError('services must be an array');
  const results = new Array(services.length);
  let next = 0;
  async function worker() {
    while (true) {
      const index = next++;
      if (index >= services.length) return;
      results[index] = await checkOne(services[index], { timeoutMs, retries, fetchImpl });
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, services.length) }, worker));
  return results;
}

async function checkOne(service, { timeoutMs, retries, fetchImpl }) {
  const started = performance.now();
  let status = 'down';
  let code = null;
  let attempts = 0;
  for (let attempt = 0; attempt <= retries; attempt++) {
    attempts++;
    const controller = new AbortController();
    let timer;
    let timedOut = false;
    const deadline = new Promise(resolve => {
      timer = setTimeout(() => { timedOut = true; controller.abort(); resolve({ timeout: true }); }, timeoutMs);
    });
    let request;
    try {
      request = Promise.resolve().then(() => fetchImpl(service.url, { signal: controller.signal }));
      // Consume late fetch outcomes without holding the expired attempt or worker slot.
      request.then(response => {
        if (timedOut) cancelBody(response);
      }, () => {});
      const outcome = await Promise.race([request.then(response => ({ response }), error => ({ error })), deadline]);
      if (outcome.timeout) {
        status = 'timeout'; code = null;
      } else if (outcome.error) {
        status = 'down'; code = null;
      } else {
        const response = outcome.response;
        code = response.status;
        status = response.ok ? 'up' : 'down';
        const cleanup = response.body?.cancel;
        if (typeof cleanup === 'function') {
          try {
            const cleaning = Promise.resolve().then(() => cleanup.call(response.body));
            cleaning.catch(() => {});
            const cleaned = await Promise.race([cleaning.then(() => true, () => true), deadline]);
            if (cleaned?.timeout) { status = 'timeout'; code = null; }
          } catch { /* cleanup is best effort */ }
        }
      }
    } catch {
      status = timedOut ? 'timeout' : 'down'; code = null;
    } finally {
      clearTimeout(timer);
    }
    if (status === 'up') break;
    if (status !== 'timeout' && code !== null && !(code === 429 || (code >= 500 && code <= 599))) break;
  }
  return { name: service.name, url: service.url, status, code, latencyMs: Math.round(performance.now() - started), attempts };
}
