const COLUMNS = [
  ['SERVICE', 'name'],
  ['STATUS', 'status'],
  ['HTTP', 'code'],
  ['LATENCY', 'latencyMs'],
  ['ATTEMPTS', 'attempts'],
];

function display(value) {
  return value === null || value === undefined ? '-' : String(value);
}

export function formatReport(results) {
  const rows = results.map(result => COLUMNS.map(([, key]) => display(result[key])));
  const headers = COLUMNS.map(([header]) => header);
  const widths = headers.map((header, index) =>
    Math.max(header.length, ...rows.map(row => row[index].length)),
  );
  const line = values => `| ${values.map((value, index) => value.padEnd(widths[index])).join(' | ')} |`;
  const separator = `+-${widths.map(width => '-'.repeat(width)).join('-+-')}-+`;
  const counts = { up: 0, down: 0, timeout: 0 };
  for (const result of results) {
    if (Object.hasOwn(counts, result.status)) counts[result.status]++;
  }

  return [
    separator,
    line(headers),
    separator,
    ...rows.map(line),
    separator,
    `Summary: up ${counts.up}, down ${counts.down}, timeout ${counts.timeout}`,
  ].join('\n');
}
