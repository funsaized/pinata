import { test } from 'node:test';
import assert from 'node:assert/strict';
import { checkServices } from '../src/check.mjs';

const service = (name) => ({ name, url: `https://${name.toLowerCase()}.invalid` });
const response = (status = 200, body) => ({ status, ok: status >= 200 && status < 300, body });

test('returns an up result for a successful response', async () => {
  const result = await checkServices([service('API')], { fetchImpl: async () => response() });
  assert.equal(result[0].name, 'API');
  assert.equal(result[0].status, 'up');
});

test('preserves input ordering when checks finish out of order', async () => {
  const result = await checkServices([service('A'), service('B')], { concurrency: 2, fetchImpl: async url => { if (url.includes('a.')) await new Promise(r => setTimeout(r, 15)); return response(); } });
  assert.deepEqual(result.map(x => x.name), ['A', 'B']);
});

test('bounds whole-service concurrency', async () => {
  let active = 0, max = 0;
  await checkServices(['A','B','C','D'].map(service), { concurrency: 2, fetchImpl: async () => { max = Math.max(max, ++active); await new Promise(r => setTimeout(r, 5)); active--; return response(); } });
  assert.equal(max, 2);
});

test('retries 503 then succeeds with accurate attempts', async () => {
  let calls = 0;
  const [result] = await checkServices([service('A')], { fetchImpl: async () => response(++calls === 1 ? 503 : 200) });
  assert.equal(result.status, 'up'); assert.equal(result.attempts, 2); assert.equal(calls, 2);
});

test('does not retry 404', async () => {
  let calls = 0;
  const [result] = await checkServices([service('A')], { fetchImpl: async () => { calls++; return response(404); } });
  assert.equal(result.status, 'down'); assert.equal(result.code, 404); assert.equal(result.attempts, 1); assert.equal(calls, 1);
});

test('retries network failures', async () => {
  let calls = 0;
  const [result] = await checkServices([service('A')], { fetchImpl: async () => { if (++calls === 1) throw Error('network'); return response(); } });
  assert.equal(result.status, 'up'); assert.equal(result.attempts, 2);
});

test('classifies a deadline as timeout and aborts the request', async () => {
  let signal;
  const [result] = await checkServices([service('A')], { timeoutMs: 10, retries: 0, fetchImpl: (_url, init) => { signal = init.signal; return new Promise(() => {}); } });
  assert.equal(result.status, 'timeout'); assert.equal(result.code, null); assert.equal(signal.aborted, true); assert.equal(result.attempts, 1);
});

test('deadline bounds a never-settling body cleanup and frees the worker slot', async () => {
  const started = [];
  const result = await checkServices([service('A'), service('B')], { concurrency: 1, timeoutMs: 15, retries: 0, fetchImpl: async url => { started.push(url); return response(200, { cancel: () => new Promise(() => {}) }); } });
  assert.deepEqual(started, [service('A').url, service('B').url]);
  assert.deepEqual(result.map(x => x.status), ['timeout', 'timeout']);
});

test('cleans up a response arriving after deadline without blocking worker progress', async () => {
  let lateCleanup = 0;
  const started = [];
  const result = await checkServices([service('A'), service('B')], {
    concurrency: 1, timeoutMs: 10, retries: 0,
    fetchImpl: url => {
      started.push(url);
      if (url.includes('a.')) return new Promise(resolve => setTimeout(() => resolve(response(200, { cancel() { lateCleanup++; return Promise.reject(Error('cleanup')); } })), 30));
      return Promise.resolve(response());
    }
  });
  assert.deepEqual(started, [service('A').url, service('B').url]);
  assert.deepEqual(result.map(x => x.status), ['timeout', 'up']);
  await new Promise(resolve => setTimeout(resolve, 30));
  assert.equal(lateCleanup, 1);
});

test('reports metadata and actual attempt count', async () => {
  const [result] = await checkServices([service('A')], { retries: 0, fetchImpl: async () => response(201) });
  assert.deepEqual(Object.keys(result), ['name','url','status','code','latencyMs','attempts']);
  assert.equal(result.code, 201); assert.equal(result.attempts, 1); assert.ok(result.latencyMs >= 0);
});

test('empty input returns an empty result', async () => {
  assert.deepEqual(await checkServices([]), []);
});

test('validates options even for empty input', async () => {
  for (const options of [null, { concurrency: 0 }, { concurrency: 1.5 }, { timeoutMs: 0 }, { timeoutMs: Infinity }, { timeoutMs: 2147483648 }, { retries: -1 }, { retries: 4 }, { fetchImpl: null }]) {
    await assert.rejects(checkServices([], options), RangeError);
  }
});

test('rejects explicit invalid option values', async () => {
  for (const options of [{ timeoutMs: null }, { retries: null }, { concurrency: null }, { fetchImpl: 1 }]) await assert.rejects(checkServices([service('A')], options), RangeError);
});
