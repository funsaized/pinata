import { test } from 'node:test';
import assert from 'node:assert/strict';
import { formatReport } from '../src/report.mjs';

test('report includes required columns and service data', () => {
  const report = formatReport([
    { name: 'API', url: 'http://api.test', status: 'up', code: 200, latencyMs: 12, attempts: 1 },
    { name: 'Search', status: 'timeout', code: null, latencyMs: 1000, attempts: 2 },
  ]);
  for (const column of ['SERVICE', 'STATUS', 'HTTP', 'LATENCY', 'ATTEMPTS']) {
    assert.match(report, new RegExp(column));
  }
  for (const value of ['API', 'Search', '200', '12', '1000', '2', 'timeout']) {
    assert.ok(report.includes(value), `report includes ${value}`);
  }
});

test('report summarizes up, down, and timeout counts', () => {
  const report = formatReport([
    { status: 'up' }, { status: 'up' }, { status: 'down' }, { status: 'timeout' },
  ]);
  assert.match(report, /Summary: up 2, down 1, timeout 1/);
});

test('report handles empty input with headers and zero summary', () => {
  const report = formatReport([]);
  for (const column of ['SERVICE', 'STATUS', 'HTTP', 'LATENCY', 'ATTEMPTS']) {
    assert.ok(report.includes(column));
  }
  assert.match(report, /Summary: up 0, down 0, timeout 0/);
});

test('report does not mutate its input', () => {
  const input = [
    { name: 'API', status: 'up', code: 200, latencyMs: 12, attempts: 1 },
    { name: 'Worker', status: 'down', code: 503, latencyMs: 30, attempts: 2 },
  ];
  const before = structuredClone(input);
  formatReport(input);
  assert.deepEqual(input, before);
});
