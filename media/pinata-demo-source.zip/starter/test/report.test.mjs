import { test } from 'node:test';
import assert from 'node:assert/strict';
import { formatReport } from '../src/report.mjs';
test('report includes service names', () => {
  assert.match(formatReport([{ name: 'API', status: 'up', code: 200, latencyMs: 12, attempts: 1 }]), /API/);
});
