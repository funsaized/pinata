import { test } from 'node:test';
import assert from 'node:assert/strict';
import { checkServices } from '../src/check.mjs';
test('returns an up result for a successful response', async () => {
  const result = await checkServices([{ name: 'API', url: 'https://example.invalid' }], { fetchImpl: async () => ({ ok: true, status: 200 }) });
  assert.equal(result[0].name, 'API');
  assert.equal(result[0].status, 'up');
});
