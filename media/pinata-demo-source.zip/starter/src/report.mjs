export function formatReport(results) {
  return results.map(r => `${r.name}: ${r.status}`).join('\n');
}
