// A small starting point: requests run one at a time, without a deadline or retry.
export async function checkServices(services, options = {}) {
  const request = options.fetchImpl ?? fetch;
  const results = [];
  for (const service of services) {
    const start = performance.now();
    try {
      const response = await request(service.url);
      results.push({ name: service.name, url: service.url, status: response.ok ? 'up' : 'down', code: response.status, latencyMs: Math.round(performance.now() - start), attempts: 1 });
    } catch (error) {
      results.push({ name: service.name, url: service.url, status: 'down', code: null, latencyMs: Math.round(performance.now() - start), attempts: 1 });
    }
  }
  return results;
}
