import os,pty,subprocess,select,time,json,fcntl,termios,struct,codecs
from pathlib import Path
base=Path(__file__).resolve().parent
master,slave=pty.openpty();fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',30,116,0,0))
env=dict(os.environ,TERM='xterm-256color',COLORTERM='truecolor',PI_SKIP_VERSION_CHECK='1')
for k in ['PINATA_AGENT','PINATA_LEGACY','NO_COLOR']:env.pop(k,None)
args=['pi','--no-session','--use-theme','dark','--no-themes','--no-extensions','--no-skills','--no-prompt-templates','--no-context-files','--extension','/home/saiguy/Projects/pinata/engine/pi/extension.ts','--provider','openai','--model','gpt-6.1-sol','--thinking','low',(base/'prompt.txt').read_text()]
p=subprocess.Popen(args,cwd=base/'relay',env=env,stdin=slave,stdout=slave,stderr=slave,start_new_session=True);os.close(slave)
(base/'pid').write_text(str(p.pid));start=time.monotonic();decoder=codecs.getincrementaldecoder('utf8')('replace')
with (base/'capture/session.cast').open('w',buffering=1) as f:
 f.write(json.dumps({'version':2,'width':116,'height':30,'timestamp':int(time.time()),'env':{'TERM':'xterm-256color'}})+'\n')
 while p.poll() is None:
  if select.select([master],[],[],.15)[0]:
   try:data=os.read(master,262144)
   except OSError:break
   text=decoder.decode(data);f.write(json.dumps([round(time.monotonic()-start,4),'o',text])+'\n')
   if '\x1b[6n' in text:os.write(master,b'\x1b[1;1R')
  for c in sorted((base/'control').glob('*.json')):
   command=json.loads(c.read_text());os.write(master,command['text'].encode());c.rename(c.with_suffix('.sent'))
(base/'exit').write_text(str(p.wait()));os.close(master)
