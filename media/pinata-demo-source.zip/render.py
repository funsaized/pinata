"""Render edited, genuine PTY output with an editorial frame. No synthetic app output."""
import json, math, os, subprocess, sys
import pyte
from PIL import Image, ImageDraw, ImageFont

from pathlib import Path
ROOT = str(Path(__file__).resolve().parent)
W, H, FPS = 1600, 1000, 15
BG, CARD, TEXT, MUTED = '#0b0e16', '#131722', '#e9edf5', '#8d98ad'
CORAL, MINT, PURPLE = '#ff9d82', '#84dfc0', '#bfa9ff'
MONO=os.environ.get('PINATA_DEMO_FONT','/usr/share/fonts/TTF/JetBrainsMonoNerdFont-Regular.ttf')
BOLD=os.environ.get('PINATA_DEMO_BOLD_FONT','/usr/share/fonts/TTF/JetBrainsMonoNerdFont-Bold.ttf')
SANS='/usr/share/fonts/DejaVuSans.ttf'
if not os.path.exists(SANS): SANS='/usr/share/fonts/TTF/DejaVuSans.ttf'
def font(size, bold=False): return ImageFont.truetype(BOLD if bold else MONO, size)
F, FB = font(19), font(19, True)
TITLE, SMALL, LABEL, CAPTION = font(36,True), font(17), font(16,True), font(23)
CX, CY, CW, CH = 82, 238, 12, 22
PALETTE={'black':'#141720','red':'#e77e89','green':'#9dd69a','brown':'#e6c782','blue':'#8ab4ef','magenta':'#c8a2df','cyan':'#89d3d2','white':'#d9dce5','brightblack':'#69738a','brightred':'#ffa0a9','brightgreen':'#b8efad','brightbrown':'#ffe0a0','brightblue':'#a8c9ff','brightmagenta':'#e1beff','brightcyan':'#a8efee','brightwhite':'#ffffff'}
def color(value, default):
  if value=='default': return default
  if value in PALETTE: return PALETTE[value]
  if len(value)==6: return '#'+value
  return default

def draw_screen(screen, segment, progress, seconds):
  im=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(im)
  d.text((64,29),'piñata',font=font(26,True),fill=CORAL)
  d.text((187,36),'1.0  /  A TEAM INSIDE PI',font=SMALL,fill=MUTED)
  d.text((1230,36),'REAL APP · LIVE MODELS',font=LABEL,fill=MINT)
  d.text((64,78),segment['title'],font=TITLE,fill=TEXT)
  stages=['PLAN','BUILD','WATCH','REVIEW','SHIP','AUTOMATE']
  for i,name in enumerate(stages):
    x=64+i*248
    active=i==segment['stage']
    d.rounded_rectangle((x,143,x+230,177),radius=8,fill='#252638' if active else '#141926')
    d.text((x+12,150),f'{i+1:02d}  {name}',font=LABEL,fill=PURPLE if active else MUTED)
  d.rounded_rectangle((62,198,1538,920),radius=12,fill=CARD,outline='#2c3345',width=1)
  for i,c in enumerate(['#ed786f','#ecc574','#7dcaa2']): d.ellipse((82+i*20,213,90+i*20,221),fill=c)
  d.text((160,207),'pulse  /  pi + piñata',font=SMALL,fill=MUTED)
  mode=segment.get('mode','')
  d.text((1515-d.textlength(mode,font=LABEL),209),mode,font=LABEL,fill=MINT)
  # Editorial crops use only cells from the recorded terminal.
  crop=segment.get('crop',[0,0,screen.columns,screen.lines])
  left,top,cols,rows=crop
  zoom=segment.get('zoom',1)
  cw,ch=CW*zoom,CH*zoom
  ox=82+(1392-cols*cw)/2
  oy=238+(660-rows*ch)/2
  regular,bold=(F,FB) if zoom==1 else (font(round(19*zoom)),font(round(19*zoom),True))
  for y in range(top,top+rows):
    line=screen.buffer[y]; x=left
    while x<left+cols:
      c=line[x]; style=(c.fg,c.bg,c.bold,c.reverse,c.italics,c.underscore)
      end=x+1
      while end<left+cols:
        n=line[end]
        if (n.fg,n.bg,n.bold,n.reverse,n.italics,n.underscore)!=style: break
        end+=1
      fg,bg=color(c.fg,TEXT),color(c.bg,CARD)
      if c.reverse: fg,bg=bg,fg
      if bg!=CARD: d.rectangle((ox+(x-left)*cw,oy+(y-top)*ch,ox+(end-left)*cw,oy+(y-top+1)*ch),fill=bg)
      for xx in range(x,end):
        glyph=line[xx].data
        if glyph and glyph!=' ': d.text((ox+(xx-left)*cw,oy+(y-top)*ch-1),glyph,font=bold if c.bold else regular,fill=fg,stroke_width=0)
      x=end
  caption=segment.get('caption','')
  d.text((64,943),caption,font=CAPTION,fill=TEXT)
  badge=segment.get('badge','')
  d.text((1536-d.textlength(badge,font=SMALL),947),badge,font=SMALL,fill=CORAL)
  d.rectangle((0,994,int(W*progress),999),fill=PURPLE)
  return im

def main():
  spec=json.load(open(ROOT+'/edit.json'))
  tracks={}
  for name in {s.get('source','session') for s in spec}:
    raw=[json.loads(l) for l in open(ROOT+'/capture/'+name+'.cast')]
    tracks[name]={'events':[e for e in raw[1:] if e[1]=='o'],'idx':0,'time':-1,'screen':pyte.Screen(116,30)}
    tracks[name]['stream']=pyte.Stream(tracks[name]['screen'])
  total=sum(s['duration'] for s in spec)
  output=sys.argv[1] if len(sys.argv)>1 else ROOT+'/pinata-demo.mp4'
  p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','26','-pix_fmt','yuv420p','-movflags','+faststart',output],stdin=subprocess.PIPE)
  elapsed=0
  for n,s in enumerate(spec):
    track=tracks[s.get('source','session')]
    if s['start']<track['time']:
      track['screen']=pyte.Screen(116,30); track['stream']=pyte.Stream(track['screen']); track['idx']=0
    screen,stream,events,idx=track['screen'],track['stream'],track['events'],track['idx']
    frames=round(s['duration']*FPS)
    for frame in range(frames):
      t=s['start']+(s['end']-s['start'])*frame/max(1,frames-1)
      while idx<len(events) and events[idx][0]<=t:
        stream.feed(events[idx][2]); idx+=1
      im=draw_screen(screen,s,(elapsed+frame/FPS)/total,elapsed+frame/FPS)
      p.stdin.write(im.tobytes())
      if frame==frames//2:
        im.save(ROOT+f'/chapter-{n+1:02d}.png')
        if s.get('poster'): im.save(ROOT+'/pinata-demo-poster.png')
    track['idx']=idx; track['time']=s['end']
    elapsed+=s['duration']
    print(f'chapter {n+1}: {elapsed:.1f}s',flush=True)
  p.stdin.close(); assert p.wait()==0
if __name__=='__main__': main()
