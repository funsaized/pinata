import json,sys
from pathlib import Path
import pyte
root=Path(__file__).resolve().parent
screen=pyte.Screen(116,30);stream=pyte.Stream(screen)
end=float(sys.argv[1]) if len(sys.argv)>1 else float('inf')
for line in (root/'capture/session.cast').read_text().splitlines()[1:]:
 e=json.loads(line)
 if e[0]>end:break
 if e[1]=='o':stream.feed(e[2])
print('\n'.join(screen.display));print('time:',e[0])
