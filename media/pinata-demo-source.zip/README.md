# piñata 2.0.1 demo source

This is genuine Pi 1.4.0 output recorded on 2026-10-31 with the pi-pinata 2.0.1
release candidate. The disposable Relay fixture starts as module stubs and a
requirements document. No agent output, progress, review verdict, or test result
was synthesized. An earlier no-color take was abandoned; only the new run is
included here.

## Render the edit offline

Install Python 3.11+, the packages in requirements.txt, FFmpeg, and JetBrains Mono
Nerd Font regular/bold. Set PINATA_DEMO_FONT and PINATA_DEMO_BOLD_FONT to alternate
monospaced TrueType fonts if needed. PINATA_DEMO_SYMBOL_FONT optionally supplies a
font for the information symbol (the original uses Adwaita Mono).
PINATA_DEMO_TOOL_FONT optionally supplies the tool symbol (Noto Sans Symbols).

    python render.py pinata-demo.mp4

edit.json records every source interval, duration, caption, crop, and playback
badge. capture/session.cast is the original 116×30 PTY output. The edit cuts setup,
waiting, and repeated output. Screen contents are drawn from that capture; headings,
chapter tabs, captions, numbered outlines, and speed badges are editorial. The
70-second edit accelerates routine work and pauses to explain key states. The result is silent H.264
at 1600×1000, 15 fps. Frozen frames and accelerated intervals are labeled.

## Verify the finished result

Use Node 22.19+; the recording used Node 26.7.0. No package installation is needed.

    cd finished
    npm test
    node bin/relay.mjs data/events.jsonl

The application files and tests were written by four builder agents, each followed
by an independent reviewer. Two scouts supplied contract and test guidance. The
CLI builder depended on all three module reviews. The parent called the handoff and
integration tools and ran destination checks. Its final checkout was not staged
or committed.

evidence/ contains actual task results, engine check logs, and integration evidence.
summary.json records the task statuses and worker usage reported by the engine.
The original paths are provenance; they refer to a disposable recording directory,
not locations to use on another machine. job.json is the interactive pinata_run
request, including background mode; it is not a ready-to-run headless CLI job.
record.py is the environment-specific recorder, retained for transparency. Adapt
its extension path and job worktreeRoot before a separately authorized live rerun.
No credentials are included. Offline rendering and npm test do not call models.

Models: OpenAI gpt-6.1-sol (low) for the parent; gpt-6-luna for workers (low scouts,
medium builders, high reviewers). Workers use the in-process backend and the built-in
scout, builder, and reviewer definitions. The captured UI uses Pi's dark theme.
