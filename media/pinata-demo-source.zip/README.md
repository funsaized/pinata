# piñata 1.0 demo source

Recorded on 2026-10-29 from pi-pinata 1.0.0, application commit d09c20a.
The terminal streams contain actual Pi 1.1.0 output. No model responses or
agent statuses were synthesized. The Pulse starter and its local HTTP services
are a purpose-built demonstration fixture.

## Re-render the video offline

Install Python 3.12+, FFmpeg, pyte 0.8.2 and Pillow 13.0.0. Install JetBrains Mono
Nerd Font (regular and bold), or point PINATA_DEMO_FONT and PINATA_DEMO_BOLD_FONT
at your own monospaced TrueType font files. From this extracted directory:

    python render.py pinata-demo.mp4

The renderer reads capture/session.cast and capture/viewer.cast. edit.json is
the edit decision list; source times are seconds within the named terminal
capture. Crops, chapter titles, captions and speed badges are editorial.
The 50-second edit opens and closes on the recorded piñata, with editorial
callouts identifying its ribbons as subagents. Three chapters cover the team,
parallel builders, and independent review through passing tests and the result.
Other cuts omit terminal setup, waiting and repeated output. The verified live
view used for the opening and closing was opened again after integration. No audio is included.

## Fixture and evidence

starter/ is the initial repository content. finished/ is the integrated result.
audit.json is the headless job; its cwd is "pulse" as used in the recording.
evidence/ contains the build/review results, real check logs, and integration
journal from run 4a950ab0. Absolute paths in the saved evidence name the original
disposable repository and are provenance, not paths to use on another machine.
The fixture is illustrative code, not a supported component of pi-pinata.

The actual coordinator used OpenAI gpt-6.1-sol (medium); workers used gpt-6-luna
(low scouts, medium builder/planner, high reviewers). The interactive and
process backends used the local Pi 1.1.0 CLI. The recording used an isolated Pi
configuration and the repository's subagents skill. Credentials are not included.
